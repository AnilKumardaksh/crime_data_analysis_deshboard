from fastapi import FastAPI
import pandas as pd
from model import CrimePredictor
import os

app = FastAPI()
predictor = CrimePredictor()

# Load data for stats
DATA_PATH = "data/crime_data.csv"

@app.get("/data")
def get_data():
    df = pd.read_csv(DATA_PATH)
    return df.to_dict(orient="records")

@app.get("/stats")
def get_stats():
    df = pd.read_csv(DATA_PATH)
    total_crimes = int(df["count"].sum())
    common_type = df.groupby("crime_type")["count"].sum().idxmax()
    dangerous_state = df.groupby("state")["count"].sum().idxmax()
    safest_state = df.groupby("state")["count"].sum().idxmin()
    
    # YoY
    crimes_2021 = df[df["year"] == 2021]["count"].sum()
    crimes_2022 = df[df["year"] == 2022]["count"].sum()
    yoy = ((crimes_2022 - crimes_2021) / crimes_2021) * 100 if crimes_2021 > 0 else 0
    
    return {
        "totalCrimes": total_crimes,
        "commonType": common_type,
        "dangerousState": dangerous_state,
        "safestState": safest_state,
        "yoyChange": round(yoy, 2)
    }

@app.get("/predict")
def predict():
    predictions = predictor.predict_future(5)
    return predictions

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
